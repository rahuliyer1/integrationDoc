<?php
use FDDLL\FirstPayRequest;

require_once 'firstPayRequest.php';
require_once 'AesCipher.php';

class firstPayForm{
    public $resultURL;
    public $amount;
    public $currencyCode;
    public $clientTransactionId;
    public $transactionType;
    public $customerId;
    public $hostedIds;
    public $firstName;
    public $lastName;
    public $middleName;
    public $suffix;
    public $mobileNo;
    public $emailId;
    public $merchantId;
    public $billingAddress_street1;
    public $billingAddress_stree2;
    public $billingAddress_city;
    public $billingAddress_state;
    public $billingAddress_country;
    public $billingAddress_zipcode;
    public $shippingAddress_street1;
    public $shippingAddress_stree2;
    public $shippingAddress_city;
    public $shippingAddress_state;
    public $shippingAddress_country;
    public $shippingAddress_zipcode;
    public $firstPayWalletCode;
    public $firstPayWalletName;
    public $vPAId;
    public $integrationType;
    public $paymentMethodType;
    public $firstPayBankCode;
    public $bankName;
    public $productId;
    public $productDescription;
    public $quantity;
    public $price;
    public $txnAmount;
    public $shippingFee;
    public $discountPrice;
    public $cardNumber;
    public $expMonth;
    public $expYear;
    public $cVV;
    public $nameOnCard;
    public $valutCard;
    public $passengerName;
    public $ticketNo;
    public $issuingCarrier;
    public $flightNo;
    public $travelAgencyName;
    public $travelRoute;
    public $depattureDate;
    public $origin;
    public $destination;
    public $carrrierCode;
    public $serviceClass;
    public $stopoverType;
    public $fareBasisCode;
    public $airlineInvoiceNo;
    public $customerCode;
    public $travelAgencyCode;
    public $depatureTax;
    public $udf1;
    public $udf2;
    public $udf3;
    public $udf4;
    public $udf5;
    public $udf6;
    public $udf7;
    public $udf8;
    public $udf9;
    public $udf10;
    public $key;
    public $iv;
    public $fpURL;
	public $sessionTokenExpireDate;
	public $configId;
    
      
    public function __get($property) {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }
    
    public function __set($property, $value) {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
        
        return $this;
    }
    
 
    public  function __construct() {
            $argv = func_get_args();
           
            switch( func_num_args() ) {
                case 0:
                    self::__construct1();
                    break;              
                case 14:
                    self::__construct2( $argv[0], $argv[1], $argv[2],$argv[3], $argv[4], $argv[5], $argv[6],$argv[7], $argv[8], $argv[9],$argv[10], $argv[11], $argv[12],$argv[13] );
            }
        }
        
        public   function __construct1() {

        }
        
       
  
    
    
    public function __construct2( $merchantId,$key,$iv,$fpURL,$amount,$currencyCode,$clientTransactionId,$transactionType,$firstName,$lastName,$middleName,$mobileNo,$emailId,$resultURL)
    {
        $this->merchantId = $merchantId;
        $this->key = $key;
        $this->iv = $iv;
        $this->fpURL=$fpURL;
        $this->amount = $amount;
        $this->currencyCode  = $currencyCode;
        $this->clientTransactionId = $clientTransactionId;
        $this->transactionType = $transactionType;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->middleName = $middleName;
        $this->mobileNo = $mobileNo;
        $this->emailId = $emailId;
        $this->resultURL = $resultURL;
        //$this->integrationType = "";
    }
    public static function object_2_array($result)
    {
        $array = array();
        foreach ($result as $key=>$value)
        {
            # if $value is an array then
            if (is_array($value))
            {
                #you are feeding an array to object_2_array function it could potentially be a perpetual loop.
                $array[$key]=firstPayForm::object_2_array($value);
            }
            
            # if $value is not an array then (it also includes objects)
            else
            {
                # if $value is an object then
                if (is_object($value))
                {
                    $array[$key]=firstPayForm::object_2_array($value);
                } else {
                    if(!is_null($value))
                        $array[$key]=$value;
                }
            }
        }
        return $array;
    }
    public static function calcHmac(string $data, string $Key)
    {
        return hash_hmac('sha512',$data,$Key);
    }
    
	
	
    public static function curlCall($merchantID,$encryptData,$url,$hmacCode=''){
        $curl = curl_init();
        if (!$curl) {
            die("Couldn't initialize a cURL handle");
        }
        echo 'cURL Initialized ';
        if(isset($hmacCode)&&!empty($hmacCode)){
            $headers = array(
                'Content-Type: application/json',
                'HMAC:'.$hmacCode,
                'merchantid:'.$merchantID
            );
        }else {
            $headers = array(
                'Content-Type: application/json',
                'merchantid:'.$merchantID
            );
        }
		echo '<br></br>';
		echo 'HEADERS : ' . $hmacCode ;
		echo 'HEADERS : ' . $merchantID ;
		echo '<br></br>';
		
		
        curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
        
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $encryptData);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        
        // EXECUTE:
        $result = curl_exec($curl);
        
        echo ' Result ---- '. $result;
        
        // Check if any error has occurred
        if (curl_errno($curl))
        {
            echo 'cURL error: ' . curl_error($curl);
        }
        else
        {
            // cURL executed successfully
            //  print_r(curl_getinfo($curl));
        }
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }
    
    public function sale($bsObj) { 
       
        
        $firstPayObj = new FirstPayRequest($bsObj);        
        
        $bsArray = firstPayForm::object_2_array($firstPayObj);        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
      
        $bsObj1 = json_decode(json_encode($bsArray), FALSE);
        
		
		
        $getTokenJson = (json_encode($bsObj1,JSON_UNESCAPED_SLASHES));
		
		//print_r($getTokenJson); exit;
	
        $key = $bsObj->key;
		
		
        $key = base64_decode($key);
			
		$iv = $bsObj->iv;
		
        $iv = base64_decode($iv);
		
        $url = $bsObj->fpURL;
		
        $merchantID = $bsObj->merchantId;
		
        $AesCipher = new \AesCipher();
       // MerchantId+MerchantTxnId+Amount+CurrencyCode+Key
		$hmacString= $merchantID.$bsObj->clientTransactionId.$bsObj->amount.$bsObj->currencyCode.$bsObj->key;
		
		$encryptData =  $AesCipher->encrypt($key, $iv, $getTokenJson);
        $encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
   
        $hmacCode = firstPayForm::calcHmac($hmacString,$bsObj->key);
		

		
        return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
    }
    
    public function refund_inquiry($firstPayRefundRequest) {
        
      /*  $bsArray = firstPayForm::object_2_array($firstPayRefundRequest);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val))
                if(count($val) == 0){
                    unset($bsArray[$key]);
            }
        }*/
 
        $bsObj2 = json_decode(json_encode($firstPayRefundRequest), FALSE);
		
        $firstPayRefundRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
		
		
        
        $key = $firstPayRefundRequest->key;
        $key = base64_decode($key);
        $iv = $firstPayRefundRequest->iv;
        $iv = base64_decode($iv);
        $url = $firstPayRefundRequest->fpURL;
		//echo($url);exit;
        $merchantID = $firstPayRefundRequest->merchantId;
        
        $AesCipher = new \AesCipher();
        
		//print_r($firstPayRefundRequestJson);exit;
		
        $encryptData =  $AesCipher->encrypt($key, $iv, $firstPayRefundRequestJson);
        $encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
		
        return firstPayForm::curlCall($merchantID,$encryptedPayload,$url);
        
    }
	
	 public function inquiry($firstPayInquiryRequest) {
        
      /*  $bsArray = firstPayForm::object_2_array($firstPayInquiryRequest);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val))
                if(count($val) == 0){
                    unset($bsArray[$key]);
            }
        }*/
 
        $bsObj2 = json_decode(json_encode($firstPayInquiryRequest), FALSE);
  
        $firstPayInquiryRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
        
        $key = $firstPayInquiryRequest->key;
        $key = base64_decode($key);
        $iv = $firstPayInquiryRequest->iv;
        $iv = base64_decode($iv);
        $url = $firstPayInquiryRequest->fpURL;
        $merchantID = $firstPayInquiryRequest->merchantId;
        
        $AesCipher = new \AesCipher();
        
        $encryptData =  $AesCipher->encrypt($key, $iv, $firstPayInquiryRequestJson);
		 $encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
        
        return firstPayForm::curlCall($merchantID,$encryptedPayload,$url);
        
    }
}