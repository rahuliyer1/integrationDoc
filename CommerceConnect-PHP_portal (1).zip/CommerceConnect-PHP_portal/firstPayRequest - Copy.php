<?php

namespace FDDLL{
    class TransactionDetails
    {
        
        public $amount;
        public $currencyCode; 
        public $clientTransactionId;
        public $transactionType;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }            
            return $this;
        }
    }
    
    class Name
    {
        public $firstName;
        public $lastName;
        public $middleName;
        public $suffix;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class billingAddress
    {
        public $street1;
        public $stree2;
        public $city;
        public $state;
        public $country;
        public $zipcode;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class shippingAddress
    {
        public $street1;
        public $stree2;
        public $city;
        public $state;
        public $country;
        public $zipcode;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class customerDetails
    {
        public $customerId;
        public $hostedIds;
        public $name;
        public $mobileNo;
        public $emailId;
       // public $merchantId;
        public $billingAddress;
        public $shippingAddress;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        public function __construct(Name $name,Billingaddress $billingAddress,ShippingAddress $shippingAddress)
        {
            $this->name = $name;
            $this->billingAddress = $billingAddress;
            $this->shippingAddress = $shippingAddress;
        }
    }
    
    
    class CardData
    {
        
        public $cardNumber;
        public $expMonth;
        public $expYear;
        public $cVV;
        public $nameOnCard;
        public $valutCard;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    
    class BankData
    {
        public $firstPayBankCode;
        public $bankName;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class WalletData
    {
        public $firstPayWalletCode;
        public $firstPayWalletName;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class UpiData
    {
        public $vPAId;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class productData
    {
        public $productId;
        public $productDescription;
        public $quantity;
        public $price;
        public $txnAmount;
        public $shippingFee;
        public $discountPrice;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        
    }
    class AirlineInfo
    {
        public $passengerName;
        public $ticketNo;
        public $issuingCarrier;
        public $flightNo;
        public $travelAgencyName;
        public $travelRoute;
        public $depattureDate;
        public $origin;
        public $destination;
        public $carrrierCode;
        public $serviceClass;
        public $stopoverType;
        public $fareBasisCode;
        public $airlineInvoiceNo;
        public $customerCode;
        public $travelAgencyCode;
        public $depatureTax;
        
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class Udf
    {
        public $udf1;
        public $udf2;
        public $udf3;
        public $udf4;
        public $udf5;
        public $udf6;
        public $udf7;
        public $udf8;
        public $udf9;
        public $udf10;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    
 
    class FirstPayRequest
    {
        public $resultURL;
        public $transactionDetails;       
        public $customerDetails;
       
        public $walletdata;
        public $upidata;    
        public $integrationType;  
        public $paymentMethodType;
       
        public $bankData;
        public $productData;
        public $carddata;
        public $airlineInfo;        
        public $udf;
       
       
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        
             
        public function __construct()
        {
           
            $name = new Name();
            $billingaddress = new Billingaddress();
            $shippingAddress = new ShippingAddress();           
            
            $this->transactionDetails = new TransactionDetails();
           
            $this->customerDetails = new CustomerDetails($name,$billingaddress,$shippingAddress);
            $this->carddata = new  CardData();
            $this->walletdata = new WalletData();            
            $this->upidata = new UpiData();
            $this->productData = new ProductData();           
            $this->bankData =  new BankData();           
            $this->airlineInfo = new AirlineInfo();
            $this->udf = new Udf();     
            
            
        }
              
        
        public function calcHmac(string $data, string $Key)
        {
            return hash_hmac('sha512',$data,$Key);
        }
       
       
    }
    
}