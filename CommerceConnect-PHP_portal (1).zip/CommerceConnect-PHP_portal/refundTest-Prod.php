<?php

namespace PaymentGateway;
require_once 'FirstPayRefundRequest.php';
require_once 'FirstPayRefundResponse.php';
require_once('firstPayFormRequest.php');
$firstPayRefundRequest =  new FirstPayRefundRequest();



$bsObj = new \firstPayForm();


$firstPayRefundRequest->merchantTxnId = "202203200703";
$firstPayRefundRequest->fpTransactionId = "2022032066093240";
$firstPayRefundRequest->refundAmount = "2.35";
$firstPayRefundRequest->merchantId = "470000000255972";


$firstPayRefundRequest->fpURL ='https://www.fdconnect.com/FDConnectL3Services/refundTxnDetail';
$firstPayRefundRequest->key = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
$firstPayRefundRequest->iv = "dLZmkqqFBGmnJ2LtLIY0fA==";


$response = new FirstPayRefundResponse();
$response = json_decode($bsObj->refund_inquiry($firstPayRefundRequest));
var_dump($response); 
