<?php

namespace PaymentGateway;

require_once 'FirstPayInquiryRequest.php';
require_once 'FirstPayInquiryResponse.php';
require_once('firstPayFormRequest.php');
$firstPayInquiryRequest = new FirstPayInquiryRequest();

$bsObj = new \firstPayForm();

$firstPayInquiryRequest->merchantTxnId = "202203151341";
$firstPayInquiryRequest->fpTransactionId = "2022031531021040";

$firstPayInquiryRequest->fpURL ="https://test.fdconnect.com/FirstPayL2Services/getTxnInquiryDetail";
$firstPayInquiryRequest->key = "X2yxsmm7G7yHVikEiuGP1IPdtbT8rPfOqCEVFLh1GQg=";
$firstPayInquiryRequest->iv = "Vb5xg9Y08yQOhOvmQ/Sg0w==";
$firstPayInquiryRequest->merchantId = "470000066755053";

$response1 = new \RootObject();
$response1 = json_decode($bsObj->inquiry($firstPayInquiryRequest));
var_dump($response1);
