<?php

namespace PaymentGateway;
require_once 'FirstPayRefundRequest.php';
require_once 'FirstPayRefundResponse.php';
require_once('firstPayFormRequest.php');
$firstPayRefundRequest =  new FirstPayRefundRequest();

$bsObj = new \firstPayForm();

$firstPayRefundRequest->merchantTxnId = "202203151341";
$firstPayRefundRequest->fpTransactionId = "2022031531021040";
$firstPayRefundRequest->refundAmount = "1";
$firstPayRefundRequest->merchantId = "470000066755053";


$firstPayRefundRequest->fpURL ="https://test.fdconnect.com/FirstPayL2Services/refundTxnDetail";
$firstPayRefundRequest->key = "X2yxsmm7G7yHVikEiuGP1IPdtbT8rPfOqCEVFLh1GQg=";
$firstPayRefundRequest->iv = "Vb5xg9Y08yQOhOvmQ/Sg0w==";


$response = new FirstPayRefundResponse();
$response = json_decode($bsObj->refund_inquiry($firstPayRefundRequest));
var_dump($response); 
