<?php
require_once('firstPayFormRequest.php');
require_once 'firstPayResponse.php';
if(isset($_POST['submit']) && !empty($_POST['clientid']))
{
    $randnum = mt_rand(10000000, 99999999);
    $response = new \FristPayResponse();
    $bsObj = new \firstPayForm("470000066755053", "X2yxsmm7G7yHVikEiuGP1IPdtbT8rPfOqCEVFLh1GQg=", "Vb5xg9Y08yQOhOvmQ/Sg0w==", "https://test.fdconnect.com/FirstPayL2Services/getToken",$_POST['amount'], "INR",$_POST['clientid'], "SALE","ABC", "XYZ", "DEF", "1234567890", "abc@gmail.com", "http://127.0.0.1/CommerceConnect-PHP_portal/sampleTestResult.php");
    $bsObj->integrationType="MERCHANT_PAYMENT_MODE_BANKORWALLET_INTEGRATION";
	$bsObj->paymentMethodType="NETBANKING";
  	$bsObj->firstPayBankCode= "ICICNB";
	$bsObj->bankName= "ICICI Bank";
    $response = json_decode($bsObj->sale($bsObj));
   // $response = json_decode($bsObj->sale($bsObj));
    
    if(isset($response->response->sessionTokenId)){
        $sessiontokenID = $response->response->sessionTokenId;
        
        $configID="PageId2020020377094";
        $redirectURL = "https://test.fdconnect.com/Pay/?sessionToken=$sessiontokenID&configId=$configID";
        
        header("Location:$redirectURL");
    }else{
        
        echo "Something went wrong............";
    }
}

?>
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method = "post">

        <div class="row">
          <div class="col-50">
            <h3>FIRSTPAY - SAMPLE MERCHANT  -- PHP Verson </h3>
            
            <div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i> Transaction Type</label>
               <input type="text" id="transactiontype" name="transactiontype" placeholder="Sale" value="Sale" readonly>
              </div>
              <div class="col-50">
                <label for="zip">Merchant ID</label>
                <input type="text" id="merchantid" name="merchantid" placeholder="10001" value="470000066755053" readonly>
              </div>
            </div>
          

          <div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i> Client Transaction Id</label>
               <input type="text" id="clientid" name="clientid" placeholder="Give unique ID" value="" >
              </div>
              <div class="col-50">
                <label for="zip">Amount</label>
                <input type="text" id="amount" name="amount" placeholder="1.5" value="1.5" >
              </div>
            </div>
          
			<div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i>Currency Code</label>
               <input type="text" id="currency" name="currency" placeholder="INR" value="INR" readonly>
              </div>
              <div class="col-50">
                <label for="zip">Page ID / Config ID</label>
                <input type="text" id="pageid" name="pageid" placeholder="470000066755053" value="PageId2020020377094">
              </div>
            </div>
         </div> 
        </div>
       
        <input type="submit" value="Continue to checkout" class="btn" name="submit">
      </form>
    </div>
  </div>

 
</div>
<style>
.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (and change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
