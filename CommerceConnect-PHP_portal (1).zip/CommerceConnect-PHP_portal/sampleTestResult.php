<?php
$fpTxnId=$_REQUEST['fpTxnId'];
$encData=$_REQUEST['encData'];
$merchantId=$_REQUEST['merchantId'];
//echo $merchantId.'+++++++++';
//echo $fpTxnId." ".$encData."+++++++++ ".$merchantId;exit;


include("firstPayResult.php");

$bsObj = new \firstPayResult($merchantId, $encData,$fpTxnId);
$getJson = (json_encode($bsObj,JSON_UNESCAPED_SLASHES));

$response =  $bsObj->curlCall($merchantId,$getJson,'https://test.fdconnect.com/FirstPayL2Services/decryptMerchantResponse');

$jsonObject = json_decode($response,true);

?>

<div class="row">
<div class="col-75">
<div class="container">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method = "post">
    
    <div class="row">
    	<div class="col-50">
            <h3>FIRSTPAY - SAMPLE MERCHANT</h3>
            <?php if($jsonObject ["transactionStatus"]=="SUCCESS"){?>
            <div class="row">
                <div class="col-50">
                <label for="fname"><i class="fa fa-user"></i> Thank you shopping with us!</label>
              
                </div>
                <div class="col-50">
                <label for="zip">Your order details has been sent on your registered email ID....</label>
                 <label for="zip">Order ID : <?php echo $jsonObject['merchantTxnId'];?></label>
                 <label for="zip">Order Amount : <?php echo $jsonObject['transactionAmount'];?></label>
                </div>
            </div> 
            <?php } else
        {
          ?>
             <div class="row">
                <div class="col-50">
                <label for="fname"><i class="fa fa-user"></i> Something went wrong!</label>
              
                </div>
                <div class="col-50">
                <label for="zip">Your order is cancelled please try again later....</label>
                
                </div>
            </div> 
            <?php }?>
        </div>
    </div>
    
    <input type="text" value="Happy Shopping" class="btn" name="submit">
    </form>
    </div>
    </div>
    
    
    </div>
    <style>
    .row {
        display: -ms-flexbox; /* IE10 */
        display: flex;
        -ms-flex-wrap: wrap; /* IE10 */
        flex-wrap: wrap;
        margin: 0 -16px;
}

.col-25 {
    -ms-flex: 25%; /* IE10 */
    flex: 25%;
}

.col-50 {
    -ms-flex: 50%; /* IE10 */
    flex: 50%;
}

.col-75 {
    -ms-flex: 75%; /* IE10 */
    flex: 75%;
}

.col-25,
.col-50,
.col-75 {
    padding: 0 16px;
}

.container {
    background-color: #f2f2f2;
    padding: 5px 20px 15px 20px;
    border: 1px solid lightgrey;
    border-radius: 3px;
}

input[type=text] {
    width: 100%;
    margin-bottom: 20px;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

label {
    margin-bottom: 10px;
    display: block;
}

.icon-container {
    margin-bottom: 20px;
    padding: 7px 0;
    font-size: 24px;
}

.btn {
    background-color: #4CAF50;
    color: white;
    padding: 12px;
    margin: 10px 0;
    border: none;
    width: 100%;
    border-radius: 3px;
    cursor: pointer;
    font-size: 17px;
}

.btn:hover {
    background-color: #45a049;
}

span.price {
    float: right;
    color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (and change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
    .row {
        flex-direction: column-reverse;
    }
    .col-25 {
        margin-bottom: 20px;
    }
}
</style>
