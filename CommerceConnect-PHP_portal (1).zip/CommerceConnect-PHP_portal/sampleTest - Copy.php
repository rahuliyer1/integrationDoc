<?php

namespace FDDLL;
require_once('firstPayRequest.php');
require_once 'AesCipher.php';
/*
$transactionDetails =  new TransactionDetails();
            $name = new Name();
            $billingaddress = new Billingaddress();
            $shippingAddress = new ShippingAddress();
            $customerDetails = new CustomerDetails($name,$billingaddress,$shippingAddress);
            $carddata = new  CardData();
            $walletdata = new WalletData();
            $upidata = new UpiData();
            $productData = new ProductData();
            $bankdata = new BankData();
            $airlineInfo = new AirlineInfo();
            $udf= new Udf();*/
            
$bsObj = new FirstPayRequest();
//$response = new \FristPayResponse();

        //    $bsObj = new FirstPayRequest($transactionDetails,$customerDetails,$carddata,$walletdata,$upidata,$productData,$bankdata,$airlineInfo,$udf);
            
            $bsObj->resultURL = "/FirstPayL2Services/merchantSuccessPage.jsp";
            $bsObj->transactionDetails->amount = "1.5";
            $bsObj->transactionDetails->currencyCode = "INR";
            
            $bsObj->transactionDetails->clientTransactionId= "123456";
            $bsObj->transactionDetails->transactionType = "SALE";
           
           // $bsObj->customerDetails->merchantId ="470000000332252";
            $bsObj->customerDetails->customerId ="ABC1234";
            $bsObj->customerDetails->hostedIds = array("KRS1220ESFFTR8490");
           
            
            $bsObj->customerDetails->name->firstName ="ABC";
            $bsObj->customerDetails->name->lastName = "XYZ";
            $bsObj->customerDetails->name->middleName = "DEF";
            $bsObj->customerDetails->name->suffix = "ADX";
            
            $bsObj->customerDetails->mobileNo ="1234567890";
            $bsObj->customerDetails->emailId = "abc@gmail.com";
            
            $bsObj->customerDetails->billingAddress->street1 = "Ghodbandar Rode";
            $bsObj->customerDetails->billingAddress->stree2 = "Sai Nagar";
            $bsObj->customerDetails->billingAddress->city = "Mumbai";
            $bsObj->customerDetails->billingAddress->state = "Maharashtra";
            $bsObj->customerDetails->billingAddress->country = "India";
            $bsObj->customerDetails->billingAddress->zipcode = "400000";
            
            
            
            $bsObj->customerDetails->shippingAddress->street1 = "Ghodbandar Rode";
            $bsObj->customerDetails->shippingAddress->stree2 = "Sai nagar";
            $bsObj->customerDetails->shippingAddress->city = "Mumbai";
            $bsObj->customerDetails->shippingAddress->state = "Maharashtra";
            $bsObj->customerDetails->shippingAddress->country = "India";
            $bsObj->customerDetails->shippingAddress->zipcode = "400000";
            
            $bsObj->integrationType = "";
            
            $bsObj->productData->productId  ="P123";
            $bsObj->productData->productDescription ="Water Bottle";
            $bsObj->productData->quantity= "1";
            $bsObj->productData->price ="100";
            $bsObj->productData->txnAmount ="120";
            $bsObj->productData->shippingFee ="20";
            $bsObj->productData->discountPrice ="0";
           
         /*   $bsObj->bankData->firstPayBankCode = "SBOINB";
            $bsObj->bankData->bankName = "StateBankofIndia";
            
            $bsObj->paymentMethodType = "CREDITCARD";
            $bsObj->integrationType = "MERCHANT_PAYMENT_MODE_CARD_INTEGRATION";
            
            $bsObj->carddata->cardNumber = "4035874000424977";
            $bsObj->carddata->expMonth = "12";
            $bsObj->carddata->expYear = "24";
            $bsObj->carddata->cVV="123";
            $bsObj->carddata->nameOnCard="Vishal Utekar";
            $bsObj->carddata->valutCard=false;*/
           
         //   $response = $bsObj->sale($bsObj);
        //    var_dump($response);
            
            
            
            $object = array_filter((array) $bsObj);
            // $getTokenJson = json_encode((array)$object);
            
            $bsArray = object_2_array($bsObj);
            
            
            foreach ($bsArray as $key=>$val){
                if(is_array($val))
                    if(count($val) == 0){
                        unset($bsArray[$key]);
                }
            }
            
            $bsObj1 = json_decode(json_encode($bsArray), FALSE);
            
            $getTokenJson = (json_encode($bsObj1,JSON_UNESCAPED_SLASHES));
            //  echo $getTokenJson;
            $hmacCode = $bsObj->calcHmac($getTokenJson,'CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=');
            //    echo $hmacCode;exit;
            
            $key = "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";//key will require 44 characters in base64.//hexadecimal string with 64 characters
            $key = base64_decode($key);
            
            $iv = base64_decode("9T4hd3Nx0b0sMgYuyWLCTg==");
            
            $AesCipher = new \AesCipher();
            
            $encryptData =  $AesCipher->encrypt($key, $iv, $getTokenJson);
            //echo $encryptData;exit;
            /*         $decrypted = $AesCipher->decrypt($key, $encryptData);
             echo $decrypted;exit;*/
            
            function object_2_array($result)
            {
                $array = array();
                foreach ($result as $key=>$value)
                {
                    # if $value is an array then
                    if (is_array($value))
                    {
                        #you are feeding an array to object_2_array function it could potentially be a perpetual loop.
                        $array[$key]=object_2_array($value);
                    }
                    
                    # if $value is not an array then (it also includes objects)
                    else
                    {
                        # if $value is an object then
                        if (is_object($value))
                        {
                            $array[$key]=object_2_array($value);
                        } else {
                            if(!is_null($value))
                                $array[$key]=$value;
                        }
                    }
                }
                return $array;
            }
            
            
            $curl = curl_init();
            if (!$curl) {
                die("Couldn't initialize a cURL handle");
            }
            
            $headers = array(
                'Content-Type: application/json',
                'HMAC:'.$hmacCode,
                'merchantid:470000000332252'
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
            
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($curl, CURLOPT_POSTFIELDS, $encryptData);
            curl_setopt($curl, CURLINFO_HEADER_OUT, true);
            // OPTIONS:
            curl_setopt($curl, CURLOPT_URL, 'https://WWW.test.fdmerchantservices.com/FirstPayL2Services/getToken');
            
            // EXECUTE:
            $result = curl_exec($curl);
            
            
            
            // Check if any error has occurred
            if (curl_errno($curl))
            {
                echo 'cURL error: ' . curl_error($curl);
            }
            else
            {
                // cURL executed successfully
                //  print_r(curl_getinfo($curl));
            }
            if(!$result){die("Connection Failure");}  var_dump($result);
            curl_close($curl);
             