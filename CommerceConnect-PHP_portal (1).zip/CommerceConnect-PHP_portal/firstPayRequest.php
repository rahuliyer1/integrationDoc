<?php

namespace FDDLL{
    class TransactionDetails
    {
        
        public $amount;
        public $currencyCode; 
        public $clientTransactionId;
        public $transactionType;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }            
            return $this;
        }
    }
    
    class Name
    {
        public $firstName;
        public $lastName;
        public $middleName;
        public $suffix;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class billingAddress
    {
        public $street1;
        public $stree2;
        public $city;
        public $state;
        public $country;
        public $zipcode;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class shippingAddress
    {
        public $street1;
        public $stree2;
        public $city;
        public $state;
        public $country;
        public $zipcode;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class customerDetails
    {
        public $customerId;
        public $hostedIds;
        public $name;
        public $mobileNo;
        public $emailId;
       // public $merchantId;
        public $billingAddress;
        public $shippingAddress;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        public function __construct(Name $name,Billingaddress $billingAddress,ShippingAddress $shippingAddress)
        {
            $this->name = $name;
            $this->billingAddress = $billingAddress;
            $this->shippingAddress = $shippingAddress;
        }
    }
    
    
    class CardData
    {
        
        public $cardNumber;
        public $expMonth;
        public $expYear;
        public $cVV;
        public $nameOnCard;
        public $valutCard;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    class LinkPaymentData
    {
        
        public $sessionTokenExpireDate;
        public $configId;
               
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
	
    class BankData
    {
        public $firstPayBankCode;
        public $bankName;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class WalletData
    {
        public $firstPayWalletCode;
        public $firstPayWalletName;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class UpiData
    {
        public $vPAId;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class productData
    {
        public $productId;
        public $productDescription;
        public $quantity;
        public $price;
        public $txnAmount;
        public $shippingFee;
        public $discountPrice;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        
    }
    class AirlineInfo
    {
        public $passengerName;
        public $ticketNo;
        public $issuingCarrier;
        public $flightNo;
        public $travelAgencyName;
        public $travelRoute;
        public $depattureDate;
        public $origin;
        public $destination;
        public $carrrierCode;
        public $serviceClass;
        public $stopoverType;
        public $fareBasisCode;
        public $airlineInvoiceNo;
        public $customerCode;
        public $travelAgencyCode;
        public $depatureTax;
        
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    class Udf
    {
        public $udf1;
        public $udf2;
        public $udf3;
        public $udf4;
        public $udf5;
        public $udf6;
        public $udf7;
        public $udf8;
        public $udf9;
        public $udf10;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
    
 
    class FirstPayRequest
    {
        public $resultURL;
        public $transactionDetails;       
        public $customerDetails;
       
        public $walletdata;
        public $upidata;    
        public $integrationType;  
        public $paymentMethodType;
       
        public $bankData;
        public $productData;
        public $carddata;
        public $airlineInfo;        
        public $udf;
       
		public $linkPaymentData; 
	   
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
        
             
        public function __construct($firstPayForm)
        {
           
            $name = new Name();
            $billingaddress = new Billingaddress();
            $shippingAddress = new ShippingAddress();           
            
            $this->transactionDetails = new TransactionDetails();
           
            $this->customerDetails = new CustomerDetails($name,$billingaddress,$shippingAddress);
            $this->carddata = new  CardData();
            $this->walletdata = new WalletData();            
            $this->upidata = new UpiData();
            $this->productData = new ProductData();           
            $this->bankData =  new BankData();           
            $this->airlineInfo = new AirlineInfo();
			$this->linkPaymentData = new LinkPaymentData();
            $this->udf = new Udf();    
            
            
            $this->resultURL = $firstPayForm->resultURL;
            $this->transactionDetails->amount = $firstPayForm->amount;
            $this->transactionDetails->currencyCode = $firstPayForm->currencyCode;
            
            $this->transactionDetails->clientTransactionId= $firstPayForm->clientTransactionId;
            $this->transactionDetails->transactionType = $firstPayForm->transactionType;
            
            $this->customerDetails->customerId =$firstPayForm->customerId;
            $this->customerDetails->hostedIds = $firstPayForm->hostedIds;
            
            
            $this->customerDetails->name->firstName =$firstPayForm->firstName;
            $this->customerDetails->name->lastName = $firstPayForm->lastName;
            $this->customerDetails->name->middleName = $firstPayForm->middleName;
            $this->customerDetails->name->suffix = $firstPayForm->suffix;
            
            $this->customerDetails->mobileNo =$firstPayForm->mobileNo;
            $this->customerDetails->emailId = $firstPayForm->emailId;
            
            $this->customerDetails->billingAddress->street1 = $firstPayForm->billingAddress_street1;
            $this->customerDetails->billingAddress->stree2 = $firstPayForm->billingAddress_stree2;
            $this->customerDetails->billingAddress->city =$firstPayForm->billingAddress_city;
            $this->customerDetails->billingAddress->state = $firstPayForm->billingAddress_state;
            $this->customerDetails->billingAddress->country = $firstPayForm->billingAddress_country;
            $this->customerDetails->billingAddress->zipcode = $firstPayForm->billingAddress_zipcode;
            
            $this->customerDetails->shippingAddress->street1 = $firstPayForm->shippingAddress_street1;
            $this->customerDetails->shippingAddress->stree2 = $firstPayForm->shippingAddress_stree2;
            $this->customerDetails->shippingAddress->city = $firstPayForm->shippingAddress_city;
            $this->customerDetails->shippingAddress->state = $firstPayForm->shippingAddress_state;
            $this->customerDetails->shippingAddress->country = $firstPayForm->shippingAddress_country;
            $this->customerDetails->shippingAddress->zipcode = $firstPayForm->shippingAddress_zipcode;
            
            $this->walletdata->firstPayWalletCode = $firstPayForm->firstPayWalletCode;
            $this->walletdata->firstPayWalletName = $firstPayForm->firstPayWalletName;
            
            $this->upidata->vPAId = $firstPayForm->vPAId;
            
            $this->airlineInfo->passengerName= $firstPayForm->vPAId;
            $this->airlineInfo->ticketNo= $firstPayForm->vPAId;
            $this->airlineInfo->issuingCarrier= $firstPayForm->vPAId;
            $this->airlineInfo->flightNo= $firstPayForm->vPAId;
            $this->airlineInfo->travelAgencyName= $firstPayForm->vPAId;
            $this->airlineInfo->travelRoute= $firstPayForm->vPAId;
            $this->airlineInfo->depattureDate= $firstPayForm->vPAId;
            $this->airlineInfo->origin= $firstPayForm->vPAId;
            $this->airlineInfo->destination= $firstPayForm->vPAId;
            $this->airlineInfo->carrrierCode= $firstPayForm->vPAId;
            $this->airlineInfo->serviceClass= $firstPayForm->vPAId;
            $this->airlineInfo->stopoverType= $firstPayForm->vPAId;
            $this->airlineInfo->fareBasisCode= $firstPayForm->vPAId;
            $this->airlineInfo->airlineInvoiceNo= $firstPayForm->vPAId;
            $this->airlineInfo->customerCode= $firstPayForm->vPAId;
            $this->airlineInfo->travelAgencyCode= $firstPayForm->vPAId;
            $this->airlineInfo->depatureTax= $firstPayForm->vPAId;  
           
            $this->productData->productId  =$firstPayForm->productId;
            $this->productData->productDescription =$firstPayForm->productDescription;
            $this->productData->quantity= $firstPayForm->quantity;
            $this->productData->price =$firstPayForm->price;
            $this->productData->txnAmount =$firstPayForm->txnAmount;
            $this->productData->shippingFee =$firstPayForm->shippingFee;
            $this->productData->discountPrice =$firstPayForm->discountPrice;
            
             $this->bankData->firstPayBankCode = $firstPayForm->firstPayBankCode;
             $this->bankData->bankName = $firstPayForm->bankName;
             
             $this->paymentMethodType = $firstPayForm->paymentMethodType;
             $this->integrationType = $firstPayForm->integrationType;
             
             $this->carddata->cardNumber = $firstPayForm->cardNumber;
             $this->carddata->expMonth = $firstPayForm->expMonth;
             $this->carddata->expYear = $firstPayForm->expYear;
             $this->carddata->cVV=$firstPayForm->cVV;
             $this->carddata->nameOnCard=$firstPayForm->nameOnCard;
             $this->carddata->valutCard=$firstPayForm->valutCard;
             
             $this->udf->udf1=$firstPayForm->udf1;
             $this->udf->udf2=$firstPayForm->udf2;
             $this->udf->udf3=$firstPayForm->udf3;
             $this->udf->udf4=$firstPayForm->udf4;
             $this->udf->udf5=$firstPayForm->udf5;
             $this->udf->udf6=$firstPayForm->udf6;
             $this->udf->udf7=$firstPayForm->udf7;
             $this->udf->udf8=$firstPayForm->udf8;
             $this->udf->udf9=$firstPayForm->udf9;
             $this->udf->udf10=$firstPayForm->udf10; 

			 $this->linkPaymentData->sessionTokenExpireDate=$firstPayForm->sessionTokenExpireDate;
			 $this->linkPaymentData->configId=$firstPayForm->configId;			 
        }
              
        
     }
    
}