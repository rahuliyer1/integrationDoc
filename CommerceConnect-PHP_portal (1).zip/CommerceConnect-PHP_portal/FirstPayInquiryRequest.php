<?php

namespace PaymentGateway
{
    class FirstPayInquiryRequest
    {
        
        public $merchantId;
        public $key;
        public $iv;
        public $fpURL;
        public $merchantTxnId;
        public $fpTransactionId;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
}
