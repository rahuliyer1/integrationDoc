<?php

namespace PaymentGateway;

require_once 'FirstPayInquiryRequest.php';
require_once 'FirstPayInquiryResponse.php';
require_once('firstPayFormRequest.php');

$firstPayInquiryRequest = new FirstPayInquiryRequest();



$bsObj = new \firstPayForm();

$firstPayInquiryRequest->merchantTxnId = "202211031312";
$firstPayInquiryRequest->fpTransactionId = "2022031132127819";//"2019093022517507";

$firstPayInquiryRequest->fpURL ="https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail";
$firstPayInquiryRequest->key = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
$firstPayInquiryRequest->iv = "dLZmkqqFBGmnJ2LtLIY0fA==";
$firstPayInquiryRequest->merchantId = "470000000255972";


$response1 = new \RootObject();
$response1 = json_decode($bsObj->inquiry($firstPayInquiryRequest));
var_dump($response1);



